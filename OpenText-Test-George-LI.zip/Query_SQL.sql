/*Question: Calculate total income in 2018 
 for each client whose earliest order_date is 2017 */
select client, sum(income) from orders where year(order_date) = 2018 and client = (select client from orders group by client having min(year(order_date)) = 2017) group by client; 